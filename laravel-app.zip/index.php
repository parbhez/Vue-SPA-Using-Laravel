<?php
	define("RUNNING_FROM_ROOT", TRUE);
	include('public/index.php');

 ?>